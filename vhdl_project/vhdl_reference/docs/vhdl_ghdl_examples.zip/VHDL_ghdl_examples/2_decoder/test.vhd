
entity test is end;

architecture arch of test is
component decoder is
	port(a0, a1: in bit;
		 d0, d1, d2, d3: out bit);
end component;
signal a: bit_vector(1 downto 0);
signal d0, d1, d2, d3: bit;
begin
	DEC0: decoder port map(a(0),a(1),d0,d1,d2,d3);
	process
	begin
		a <= "00";
		wait for 10 ns;
		a <= "01";
		wait for 10 ns;
		a <= "10";
		wait for 10 ns;
		a <= "11";
		wait for 10 ns;
	end process;
end architecture;
