
entity dff is
	port(d, clk, reset: in bit;
		 q: out bit);
end entity;

architecture arch of dff is
begin
	process (reset, clk)
	begin
		if reset = '1' then
			q <= '0';
		elsif clk'event and clk = '1' then
			q <= d;
		end if;
	end process;
end architecture;
