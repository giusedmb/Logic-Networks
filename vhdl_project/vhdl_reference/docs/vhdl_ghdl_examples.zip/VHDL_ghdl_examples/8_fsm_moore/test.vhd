
entity test is end;

architecture arch of test is
component fsm is
	port(clock, reset: in bit;
		 e: in  bit_vector(2 downto 0);
		 u: out bit_vector(1 downto 0));
end component;
signal reset, clock: bit;
signal e: bit_vector(2 downto 0);
signal u: bit_vector(1 downto 0);
begin
	FSM0: fsm port map(clock,reset,e,u);
	process
	begin
		reset <= '1';
		clock <= '0';
		e <= "000";
		wait for 10 ns;
		reset <= '0';

		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';
		wait for 10 ns;

		e <= "001";
		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';
		wait for 10 ns;

		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';
		wait for 10 ns;

		e <= "000";
		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';
		wait for 10 ns;

		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';
		wait for 100 ns;
	end process;
end architecture;
