
entity xorgate is
	port(a, b: in bit; c: out bit);
end entity;

architecture arch of xorgate is
begin
	c <= a xor b;
end architecture;
