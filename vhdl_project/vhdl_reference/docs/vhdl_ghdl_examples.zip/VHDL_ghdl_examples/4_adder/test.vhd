
entity test is end;

architecture arch of test is
component adder is
	port(a, b, cin: in bit;
		 s, cout: out bit);
end component;
signal a, b, cin, s, cout: bit;
begin
	ADD0: adder port map(a,b,cin,s,cout);
	process
	begin
		a <= '0'; b <= '0'; cin <= '0';
		wait for 10 ns;
		a <= '1';
		wait for 10 ns;
		a <= '0'; b<= '1';
		wait for 10 ns;
		a <= '1';
		wait for 10 ns;
		a <= '0'; cin <= '1';
		wait for 10 ns;
		a <= '1';
		wait for 10 ns;
	end process;
end architecture;
