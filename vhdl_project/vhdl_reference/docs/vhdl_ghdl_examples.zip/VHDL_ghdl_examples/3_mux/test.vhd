
entity test is end;

architecture arch of test is
component mux is
	port(a, b, c, d, s0, s1: in bit;
		 y: out bit);
end component;
signal s: bit_vector(1 downto 0);
signal a, b, c, d, y: bit;
begin
	MUX0: mux port map(a,b,c,d,s(0),s(1),y);
	process
	begin
		a <= '0'; b <= '0'; c <= '0'; d <= '0';
		s <= "00";
		wait for 10 ns;
		a <= '1';
		wait for 10 ns;
		s <= "01";
		wait for 10 ns;
		b <= '1';
		wait for 10 ns;
		s <= "10";
		wait for 10 ns;
		c <= '1';
		wait for 10 ns;
		s <= "11";
		wait for 10 ns;
		d <= '1';
		wait for 10 ns;
	end process;
end architecture;
