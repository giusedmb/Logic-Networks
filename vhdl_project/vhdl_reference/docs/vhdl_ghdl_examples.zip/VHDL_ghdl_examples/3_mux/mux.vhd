
entity mux is
	port(a, b, c, d, s0, s1: in bit;
		 y: out bit);
end entity;

architecture dataflow of mux is
begin
	y <= (a and (not s1) and (not s0)) or
		 (b and (not s1) and      s0 ) or
		 (c and      s1  and (not s0)) or
		 (d and      s1  and      s0 );
end architecture;

-- architecture arch2 of mux is
-- begin
-- 	y <= a when s1 = '0' and s0 = '0' else
-- 		 b when s1 = '0' and s0 = '1' else
-- 		 c when s1 = '1' and s0 = '0' else
-- 		 d;
-- end architecture;

-- architecture arch3 of mux is
-- signal s: bit_vector(1 downto 0);
-- begin
-- 	s <= s1 & s0;
-- 	
-- 	with s select
-- 		y <= a when "00",
-- 			 b when "01",
-- 			 c when "10",
-- 			 d when others;
-- end architecture;

-- architecture arch4 of mux is
-- signal s: bit_vector(1 downto 0);
-- begin
-- 	s <= s1 & s0;
-- 	process(s,a,b,c,d)
-- 	begin
-- 		if    s = "00" then
-- 			y <= a;
-- 		elsif s = "01" then
-- 			y <= b;
-- 		elsif s = "10" then
-- 			y <= c;
-- 		else
-- 			y <= d;
-- 		end if;
-- 	end process;
-- end architecture;

-- architecture arch5 of mux is
-- signal s: bit_vector(1 downto 0);
-- begin
-- 	s <= s1 & s0;
-- 	process(s,a,b,c,d)
-- 	begin
-- 		case s is
-- 			when "00"   => y <= a;
-- 			when "01"   => y <= b;
-- 			when "10"   => y <= c;
-- 			when others => y <= d;
-- 		end case;
-- 	end process;
-- end architecture;
