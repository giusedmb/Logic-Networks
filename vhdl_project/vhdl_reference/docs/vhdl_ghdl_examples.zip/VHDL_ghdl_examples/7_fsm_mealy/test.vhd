
entity test is end;

architecture arch of test is
component fsm is
	port(clock, reset, e: in bit;
		 u: out bit);
end component;
signal reset, clock, e, u: bit;
begin
	FSM0: fsm port map(clock,reset,e,u);
	process
	begin
		reset <= '1';
		clock <= '0';
		e <= '0';
		wait for 10 ns;
		reset <= '0';

		wait for 10 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';

		wait for 5 ns;
		e <= '1';
		wait for 5 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';

		wait for 5 ns;
		e <= '0';
		wait for 5 ns;
		e <= '1';
		wait for 5 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';

		wait for 5 ns;
		e <= '0';
		wait for 5 ns;
		e <= '1';
		wait for 5 ns;
		clock <= '1';
		wait for 10 ns;
		clock <= '0';

		e <= '0';
		wait for 10 ns;

		wait for 200 ns;
	end process;
end architecture;
